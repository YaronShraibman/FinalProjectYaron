const ROUTES = {
  ABOUT: "/about",
};

export default ROUTES;
