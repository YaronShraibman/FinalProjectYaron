const initialUserEditForm = {
  first: "",
  middle: "",
  last: "",
  phone: "",
  url: "",
  alt: "",
  state: "",
  country: "",
  city: "",
  street: "",
  houseNumber: 0,
  zip: 0,
  isBusiness: false,
};

export default initialUserEditForm;
