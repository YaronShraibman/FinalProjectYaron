const initialSignupForm = {
  first: "",
  middle: "",
  last: "",
  phone: "",
  email: "",
  password: "",
  url: "",
  alt: "",
  state: "",
  country: "",
  city: "",
  street: "",
  houseNumber: 0,
  zip: 0,
  isBusiness: false,
  loginAttempts: 0,
  lastFailedAttempt: null,
};

export default initialSignupForm;
