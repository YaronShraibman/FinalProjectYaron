import React from "react";
import Button from "@mui/material/Button";

const SxProp = () => {
  return (
    <Button sx={{ color: "red" }} variant="contained" color="primary">
      click me
    </Button>
  );
};

export default SxProp;
