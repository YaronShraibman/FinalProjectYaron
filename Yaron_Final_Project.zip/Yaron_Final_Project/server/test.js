const chalk = require("chalk");

console.log(chalk.bgYellowBright("in test.js!"));
